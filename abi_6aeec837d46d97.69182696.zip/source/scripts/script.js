
class Student {

    constructor(id, name, section) {

        this.id = id;
        this.name = name;
        this.section = section;

        this.present = 0;
        this.absent = 0;

        this.status = "No Record";

        this.history = [];
    }

    markAttendance(status) {

        let today =
        new Date().toLocaleDateString();

        this.status = status;

        if(status === "Present"){
            this.present++;
        }else{
            this.absent++;
        }

        this.history.push(
        `${today} - ${status}`
        );
    }

    getAttendancePercentage(){

        let total =
        this.present + this.absent;

        if(total === 0) return 0;

        return (
        (this.present / total) * 100
        ).toFixed(2);

    }

}


class Section{

    constructor(name){

        this.name = name;
        this.students = [];

    }

    addStudent(student){

        this.students.push(student);

    }

}


class AttendanceSystem{

    constructor(){

        this.sections = [];
        this.students = [];

    }

    createSection(name){

        let section =
        new Section(name);

        this.sections.push(section);

    }

    addStudent(student){

        this.students.push(student);

        let section =
        this.sections.find(
        s=>s.name===student.section
        );

        if(section){

            section.addStudent(student);

        }

    }

    getStudent(id){

        return this.students.find(
        s=>s.id===id
        );

    }

}

const system =
new AttendanceSystem();

function createSection(){

let name =
document.getElementById(
'sectionName'
).value;

if(!name) return;

system.createSection(name);

updateSectionUI();

document.getElementById(
'sectionName'
).value='';

}

function updateSectionUI(){

const list =
document.getElementById(
'sectionList'
);

list.innerHTML='';

const sectionSelect =
document.getElementById(
'studentSection'
);

sectionSelect.innerHTML='';

system.sections.forEach(section=>{

let li =
document.createElement("li");

li.textContent =
section.name;

list.appendChild(li);

let option =
document.createElement("option");

option.value =
section.name;

option.textContent =
section.name;

sectionSelect.appendChild(option);

});

updateSummary();

}

function addStudent(){

let name =
document.getElementById(
'studentName'
).value;

let id =
document.getElementById(
'studentId'
).value;

let section =
document.getElementById(
'studentSection'
).value;

if(!name || !id) return;

let student =
new Student(
id,
name,
section
);

system.addStudent(student);

updateStudentDropdown();

renderTable();

document.getElementById(
'studentName'
).value='';

document.getElementById(
'studentId'
).value='';

}

function updateStudentDropdown(){

let dropdown =
document.getElementById(
'attendanceStudent'
);

dropdown.innerHTML='';

system.students.forEach(student=>{

let option =
document.createElement(
'option'
);

option.value =
student.id;

option.textContent =
`${student.name} (${student.id})`;

dropdown.appendChild(option);

});

}

function markAttendance(status){

let id =
document.getElementById(
'attendanceStudent'
).value;

let student =
system.getStudent(id);

if(student){

student.markAttendance(
status
);

renderTable();

updateSummary();

}

}

function renderTable(){

let table =
document.getElementById(
'studentTable'
);

table.innerHTML='';

system.students.forEach(student=>{

let row =
`
<tr>
<td>${student.name}</td>

<td>${student.section}</td>

<td class="${
student.status==="Present"
?
"present"
:
"absent"
}">
${student.status}
</td>

<td>${student.present}</td>

<td>${student.absent}</td>

<td>
${student.getAttendancePercentage()}%
</td>

<td>
${student.history.join("<br>")}
</td>
</tr>
`;

table.innerHTML += row;

});

}

function updateSummary(){

let summary =
document.getElementById(
'summary'
);

summary.innerHTML='';

system.sections.forEach(section=>{

let totalStudents =
section.students.length;

let totalPresent = 0;

let totalAbsent = 0;

section.students.forEach(student=>{

totalPresent += student.present;

totalAbsent += student.absent;

});

summary.innerHTML +=
`
<div>
<h3>${section.name}</h3>

<p>
Students:
${totalStudents}
</p>

<p>
Total Present:
${totalPresent}
</p>

<p>
Total Absent:
${totalAbsent}
</p>

</div>
<hr>
`;

});

}

async function startCamera(){

const video =
document.getElementById(
'video'
);

const stream =
await navigator
.mediaDevices
.getUserMedia({
video:true
});

video.srcObject =
stream;

}

function uploadID(){

const file =
document.getElementById(
'idUpload'
).files[0];

if(!file) return;

document.getElementById(
'uploadResult'
).innerHTML =
`
Uploaded:
<b>${file.name}</b>
`;

alert(
"Student ID uploaded successfully."
);

}